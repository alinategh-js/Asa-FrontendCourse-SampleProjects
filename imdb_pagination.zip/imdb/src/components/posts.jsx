import React from "react";

const Posts = () => {
  return <h1>Posts</h1>;
};

export default Posts;
